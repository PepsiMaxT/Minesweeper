﻿
using var game = new MineSweeper.Game1();
game.Run();
