﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MineSweeper
{
    public class Game1 : Game
    {
        int i, j, x, y;

        Texture2D[] tileSprite = new Texture2D[10];

        VisibleTile[,] visibleTile = new VisibleTile[20, 20];

        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            //Set up blank screen tile
            for (x = 0; x < 20; x++)
            {
                for (y = 0; y < 20; y++)
                {
                    visibleTile[x, y] = new VisibleTile(x, y, tileSprite[0]);
                }
            }

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            //Tile sprites
            tileSprite[0] = Content.Load<Texture2D>("Empty");
            tileSprite[1] = Content.Load<Texture2D>("One");
            tileSprite[2] = Content.Load<Texture2D>("Two");
            tileSprite[3] = Content.Load<Texture2D>("Three");
            tileSprite[4] = Content.Load<Texture2D>("Four");
            tileSprite[5] = Content.Load<Texture2D>("Five");
            tileSprite[6] = Content.Load<Texture2D>("Six");
            tileSprite[7] = Content.Load<Texture2D>("Seven");
            tileSprite[8] = Content.Load<Texture2D>("Eight");
            tileSprite[9] = Content.Load<Texture2D>("Bomb");
            tileSprite[10] = Content.Load<Texture2D>("Flag");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            spriteBatch.Draw(tileSprite[0], new Vector2(0, 0), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}