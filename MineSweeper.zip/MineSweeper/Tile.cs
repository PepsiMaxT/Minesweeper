﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MineSweeper
{
    internal class VisibleTile
    {
        public Texture2D texture;
        public int x;
        public int y;
        public Rectangle space;
        public VisibleTile(int _x, int _y, Texture2D _texture)
        {
            int x = _x;
            int y = _y;
            space = new Rectangle(x * 32, y * 32, 32, 32);
            texture = _texture;
        }
    }
}
